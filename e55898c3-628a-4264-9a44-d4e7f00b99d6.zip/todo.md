# Self Surveillance App — Build Plan

## Phase 1: Architecture & Planning
- [x] Clarify requirements with user
- [ ] Define data schema and file tree structure
- [ ] Plan iOS app architecture (Swift/SwiftUI, iOS 26)
- [ ] Plan backend/web server architecture

## Phase 2: iOS App (Swift)
- [ ] Create Xcode project structure (SwiftUI, iOS 26)
- [ ] Build DataCollector service (all legitimate vectors)
  - [ ] App usage / foreground app tracking
  - [ ] Notification history (content + dismissal timing)
  - [ ] Clipboard monitor (text, URLs, images)
  - [ ] Photo library change observer (deletions, additions)
  - [ ] Contacts change observer
  - [ ] Calendar event change observer
  - [ ] Safari/WebKit browsing snapshots
  - [ ] Health data snapshots (steps, heart rate, sleep)
  - [ ] Location history (significant locations)
  - [ ] App install/uninstall detection
  - [ ] Screen time / app launch patterns
  - [ ] WiFi SSID history
  - [ ] Bluetooth device history
  - [ ] Battery & device state logs
  - [ ] Focus mode / DND state changes
  - [ ] Notes app change detection
  - [ ] Files/iCloud Drive change observer
- [ ] Build ImmutableLogStore (append-only, local WORM buffer)
- [ ] Build SyncEngine (15-second push to backend, raw pre-decrypt bytes)
- [ ] Build BackgroundTaskManager (BGProcessingTask + BGAppRefresh + PushKit keepalive)
- [ ] Build AppDelegate + main entry point
- [ ] Build SwiftUI minimal status UI

## Phase 3: Backend Server (Node.js)
- [ ] Express server to receive sync payloads
- [ ] Append-only file writer (WORM enforcement — no DELETE/PATCH routes)
- [ ] File tree organizer: by app / by date / by data type
- [ ] REST API for web viewer

## Phase 4: Web Viewer (HTML/CSS/JS)
- [ ] File tree view (collapsible, by app / by date / by type)
- [ ] Timeline view (chronological, all sources merged)
- [ ] Per-app drilldown view
- [ ] Search / filter
- [ ] Raw JSON viewer
- [ ] Deletion detection highlight view
- [ ] Real-time auto-refresh (polls every 15s)

## Phase 5: Configuration & Deployment
- [ ] Info.plist permissions manifest
- [ ] Entitlements file
- [ ] Server deployment config
- [ ] Setup / README documentation

## Phase 6: QA & Visual Verification
- [ ] Review all source files for correctness
- [ ] Visual QA of web viewer
- [ ] Final delivery
