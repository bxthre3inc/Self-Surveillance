// MARK: - NetworkAndWiFiCollector.swift
// Monitors WiFi/network state changes using NEHotspotNetwork and
// NWPathMonitor.  Also hooks URLSessionDelegate to log network requests
// from within the app itself (SyncEngine traffic excluded).
//
// Bluetooth device discovery uses CoreBluetooth's CBCentralManager.

import NetworkExtension
import Network
import CoreBluetooth
import SystemConfiguration.CaptiveNetwork

public final class NetworkAndWiFiCollector: NSObject, CBCentralManagerDelegate {

    public static let shared = NetworkAndWiFiCollector()

    private var pathMonitor: NWPathMonitor?
    private var monitorQueue = DispatchQueue(label: "com.selfsurveillance.network.monitor")
    private var centralManager: CBCentralManager?
    private var lastSSID: String? = nil
    private var pollTimer: Timer?

    private override init() { super.init() }

    public func start() {
        startNetworkPathMonitor()
        startBluetoothScanning()
        // Poll WiFi SSID every 15s
        pollTimer = Timer.scheduledTimer(withTimeInterval: 15.0, repeats: true) { [weak self] _ in
            self?.captureWiFiState()
        }
        captureWiFiState()
    }

    public func stop() {
        pathMonitor?.cancel()
        pollTimer?.invalidate()
    }

    // MARK: - Network Path Monitor

    private func startNetworkPathMonitor() {
        let monitor = NWPathMonitor()
        pathMonitor = monitor
        monitor.pathUpdateHandler = { [weak self] path in
            self?.logNetworkPath(path)
        }
        monitor.start(queue: monitorQueue)
    }

    private func logNetworkPath(_ path: NWPath) {
        var interfaces: [String] = []
        if path.usesInterfaceType(.wifi)     { interfaces.append("wifi") }
        if path.usesInterfaceType(.cellular) { interfaces.append("cellular") }
        if path.usesInterfaceType(.wiredEthernet) { interfaces.append("ethernet") }
        if path.usesInterfaceType(.loopback) { interfaces.append("loopback") }

        let statusStr: String
        switch path.status {
        case .satisfied:     statusStr = "connected"
        case .unsatisfied:   statusStr = "disconnected"
        case .requiresConnection: statusStr = "requiresConnection"
        @unknown default:    statusStr = "unknown"
        }

        ImmutableLogStore.shared.append(
            source: .network,
            category: .deviceActivity,
            eventType: "networkPathChanged",
            payload: .networkRequest(NetworkRequestPayload(
                eventType: "networkPathChanged",
                sourceApp: nil,
                url: nil,
                domain: nil,
                httpMethod: nil,
                statusCode: nil,
                bytesSent: nil,
                bytesReceived: nil,
                isEncrypted: nil,
                certificateInfo: "interfaces=\(interfaces.joined(separator: ",")) status=\(statusStr)"
            ))
        )
    }

    // MARK: - WiFi SSID polling

    private func captureWiFiState() {
        // Use NEHotspotNetwork to get current SSID (requires WiFi entitlement)
        NEHotspotNetwork.fetchCurrent { [weak self] network in
            let ssid = network?.ssid
            let bssid = network?.bssid
            let isSecure = network?.isSecure ?? false

            guard ssid != self?.lastSSID else { return }
            self?.lastSSID = ssid

            let eventType = ssid != nil ? "connected" : "disconnected"
            ImmutableLogStore.shared.append(
                source: .wifi,
                category: .deviceActivity,
                eventType: eventType,
                payload: .wifiEvent(WiFiEventPayload(
                    eventType: eventType,
                    ssid: ssid,
                    bssid: bssid,
                    rssi: nil,
                    securityType: isSecure ? "secured" : "open",
                    frequency: nil,
                    ipAddress: self?.currentIPAddress()
                ))
            )
        }
    }

    private func currentIPAddress() -> String? {
        var address: String? = nil
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0 {
            var ptr = ifaddr
            while ptr != nil {
                defer { ptr = ptr?.pointee.ifa_next }
                let interface = ptr?.pointee
                let addrFamily = interface?.ifa_addr.pointee.sa_family
                if addrFamily == UInt8(AF_INET) || addrFamily == UInt8(AF_INET6) {
                    let name = String(cString: (interface?.ifa_name)!)
                    if name == "en0" {
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        getnameinfo(interface?.ifa_addr, socklen_t((interface?.ifa_addr.pointee.sa_len)!),
                                   &hostname, socklen_t(hostname.count), nil, socklen_t(0), NI_NUMERICHOST)
                        address = String(cString: hostname)
                    }
                }
            }
            freeifaddrs(ifaddr)
        }
        return address
    }

    // MARK: - Bluetooth scanning

    private func startBluetoothScanning() {
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }

    public func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            central.scanForPeripherals(withServices: nil,
                options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        }
    }

    public func centralManager(_ central: CBCentralManager,
                                didDiscover peripheral: CBPeripheral,
                                advertisementData: [String: Any],
                                rssi RSSI: NSNumber) {
        let name = peripheral.name ?? advertisementData[CBAdvertisementDataLocalNameKey] as? String
        let serviceUUIDs = (advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID])?
            .map { $0.uuidString }

        ImmutableLogStore.shared.append(
            source: .bluetooth,
            category: .deviceActivity,
            eventType: "discovered",
            payload: .bluetoothEvent(BluetoothEventPayload(
                eventType: "discovered",
                deviceName: name,
                deviceAddress: peripheral.identifier.uuidString,
                deviceClass: classifyBluetooth(serviceUUIDs: serviceUUIDs),
                rssi: RSSI.intValue,
                serviceUUIDs: serviceUUIDs,
                pairingLatencySeconds: nil
            ))
        )
    }

    public func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        ImmutableLogStore.shared.append(
            source: .bluetooth,
            category: .deviceActivity,
            eventType: "connected",
            payload: .bluetoothEvent(BluetoothEventPayload(
                eventType: "connected",
                deviceName: peripheral.name,
                deviceAddress: peripheral.identifier.uuidString,
                deviceClass: nil, rssi: nil, serviceUUIDs: nil, pairingLatencySeconds: nil
            ))
        )
    }

    public func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        ImmutableLogStore.shared.append(
            source: .bluetooth,
            category: .deviceActivity,
            eventType: "disconnected",
            payload: .bluetoothEvent(BluetoothEventPayload(
                eventType: "disconnected",
                deviceName: peripheral.name,
                deviceAddress: peripheral.identifier.uuidString,
                deviceClass: nil, rssi: nil, serviceUUIDs: nil, pairingLatencySeconds: nil
            ))
        )
    }

    private func classifyBluetooth(serviceUUIDs: [String]?) -> String? {
        guard let uuids = serviceUUIDs else { return nil }
        // Known service UUIDs
        let knownServices: [String: String] = [
            "110B": "audioSink",
            "110A": "audioSource",
            "1812": "hid",         // HID (keyboard, mouse, gamepad)
            "180D": "heartRate",
            "1800": "genericAccess",
            "180F": "batteryService",
            "FE9A": "airpods",
            "FD5A": "appleWatch",
        ]
        for uuid in uuids {
            let shortUUID = uuid.components(separatedBy: "-").first?.uppercased() ?? ""
            if let classification = knownServices[shortUUID] { return classification }
        }
        return nil
    }
}

import Darwin   // for getifaddrs
